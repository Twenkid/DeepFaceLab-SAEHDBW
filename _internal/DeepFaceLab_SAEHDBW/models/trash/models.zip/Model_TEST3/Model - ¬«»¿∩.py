import multiprocessing
from functools import partial

import numpy as np

from core import mathlib
from core.interact import interact as io
from core.leras import nn
from facelib import FaceType
from models import ModelBase
from samplelib import *

class QModel(ModelBase):
    #override
    def on_initialize(self):
        device_config = nn.getCurrentDeviceConfig()
        devices = device_config.devices
        self.model_data_format = "NCHW" if len(devices) != 0 and not self.is_debug() else "NHWC"
        nn.initialize(data_format=self.model_data_format)
        tf = nn.tf

        resolution = self.resolution = 96
        self.face_type = FaceType.FULL
        ae_dims = 64
        e_dims = 64
        d_dims = 64
        self.pretrain = False
        self.pretrain_just_disabled = False

        masked_training = True

        models_opt_on_gpu = len(devices) >= 1 and all([dev.total_mem_gb >= 4 for dev in devices])
        models_opt_device = '/DML:0' if models_opt_on_gpu and self.is_training else '/CPU:0'
        optimizer_vars_on_cpu = models_opt_device=='/CPU:0'

        input_ch = 3
        bgr_shape = nn.get4Dshape(resolution,resolution,input_ch)
        mask_shape = nn.get4Dshape(resolution,resolution,1)

        self.model_filename_list = []

        kernel_initializer=tf.initializers.glorot_uniform()
        class Downscale(nn.ModelBase):
            def __init__(self, in_ch, out_ch, kernel_size=5, *kwargs ):
                self.in_ch = in_ch
                self.out_ch = out_ch
                self.kernel_size = kernel_size
                super().__init__(*kwargs)

            def on_build(self, *args, **kwargs ):
                self.conv1 = nn.Conv2D( self.in_ch, self.out_ch, kernel_size=self.kernel_size, strides=2, padding='SAME')

            def forward(self, x):
                x = self.conv1(x)
                x = tf.nn.leaky_relu(x, 0.1)
                return x

            def get_out_ch(self):
                return self.out_ch

        class DownscaleBlock(nn.ModelBase):
            def on_build(self, in_ch, ch, n_downscales, kernel_size):
                self.downs = []

                last_ch = in_ch
                for i in range(n_downscales):
                    cur_ch = ch*( min(2**i, 8)  )
                    self.downs.append ( Downscale(last_ch, cur_ch, kernel_size=kernel_size) )
                    last_ch = self.downs[-1].get_out_ch()

            def forward(self, inp):
                x = inp
                for down in self.downs:
                    x = down(x)
                return x

        class Upscale(nn.ModelBase):
            def on_build(self, in_ch, out_ch, kernel_size=3 ):
                self.conv1 = nn.Conv2D( in_ch, out_ch*4, kernel_size=kernel_size, padding='SAME')

            def forward(self, x):
                x = self.conv1(x)
                x = tf.nn.leaky_relu(x, 0.1)
                x = nn.depth_to_space(x, 2)
                return x

        class ResidualBlock(nn.ModelBase):
            def on_build(self, ch, kernel_size=3 ):
                self.conv1 = nn.Conv2D( ch, ch, kernel_size=kernel_size, padding='SAME')
                self.conv2 = nn.Conv2D( ch, ch, kernel_size=kernel_size, padding='SAME')

            def forward(self, inp):
                x = self.conv1(inp)
                x = tf.nn.leaky_relu(x, 0.2)
                x = self.conv2(x)
                x = tf.nn.leaky_relu(inp + x, 0.2)
                return x

        class Encoder(nn.ModelBase):
            def on_build(self, in_ch, e_ch):
                self.down1 = DownscaleBlock(in_ch, e_ch, n_downscales=4, kernel_size=5)

            def forward(self, inp):
                return nn.flatten(self.down1(inp))

        class Classifier(nn.ModelBase):
            def on_build(self, in_ch, n_classes):
                self.conv1 = nn.Conv2D( 3, 64, kernel_size=3, strides=2, padding='SAME')
                self.conv2 = nn.Conv2D( 64, 128, kernel_size=3, strides=2, padding='SAME')
                self.conv3 = nn.Conv2D( 128, 256, kernel_size=3, strides=2, padding='SAME')
                self.conv4 = nn.Conv2D( 256, 512, kernel_size=3, strides=2, padding='SAME')

                self.dense1 = nn.Dense( 512*(resolution // (2**4))**2, 512 )
                self.class_dense = nn.Dense( 512, n_classes )

            def forward(self, inp):
                x = inp
                x = tf.nn.leaky_relu(self.conv1(x), 0.2)
                x = tf.nn.leaky_relu(self.conv2(x), 0.2)
                x = tf.nn.leaky_relu(self.conv3(x), 0.2)
                x = tf.nn.leaky_relu(self.conv4(x), 0.2)
                
                x = nn.flatten (x)   
                x = self.dense1(x)
                
                return self.class_dense(x)

        lowest_dense_res = resolution // 32
        
        class Inter(nn.ModelBase):
            def __init__(self, in_ch, ae_ch, **kwargs):
                self.in_ch, self.ae_ch = in_ch, ae_ch
                super().__init__(**kwargs)

            def on_build(self):
                in_ch, ae_ch = self.in_ch, self.ae_ch
                self.dense_norm = nn.DenseNorm()
                self.dense1 = nn.Dense( in_ch, ae_ch )
                
            def forward(self, inp):
                x = inp
                x = self.dense_norm(x)
                x = self.dense1(x)
                return x

            @staticmethod
            def get_code_res():
                return lowest_dense_res

            def get_out_ch(self):
                return self.ae_out_ch
                    

        class Decoder(nn.ModelBase):
            def on_build(self, in_ch, d_ch):
                self.in_ch = in_ch
                self.dense2 = nn.Dense( in_ch, lowest_dense_res * lowest_dense_res * in_ch )
                self.upscale0 = Upscale(in_ch, d_ch*8)                    
                self.upscale1 = Upscale(d_ch*8, d_ch*8)
                self.upscale2 = Upscale(d_ch*8, d_ch*4)
                self.upscale3 = Upscale(d_ch*4, d_ch*2)

                self.res0 = ResidualBlock(d_ch*8)
                self.res1 = ResidualBlock(d_ch*8)
                self.res2 = ResidualBlock(d_ch*4)
                self.res3 = ResidualBlock(d_ch*2)

                self.out_conv  = nn.Conv2D( d_ch*2, 3, kernel_size=1, padding='SAME',kernel_initializer=kernel_initializer)
                self.out_conv1  = nn.Conv2D( d_ch*2, 3, kernel_size=3, padding='SAME',kernel_initializer=kernel_initializer)
                self.out_conv2  = nn.Conv2D( d_ch*2, 3, kernel_size=3, padding='SAME',kernel_initializer=kernel_initializer)
                self.out_conv3  = nn.Conv2D( d_ch*2, 3, kernel_size=3, padding='SAME',kernel_initializer=kernel_initializer)
            
            
            def forward(self, inp):
                x = inp
                
                x = self.dense2(x)
                x = nn.reshape_4D (x, lowest_dense_res, lowest_dense_res, self.in_ch)                    

                x = self.upscale0(x)
                x = self.res0(x)
                x = self.upscale1(x)
                x = self.res1(x)
                x = self.upscale2(x)
                x = self.res2(x)
                x = self.upscale3(x)
                x = self.res3(x)
                
                x0 = tf.nn.sigmoid(self.out_conv(x))
                x0 = nn.upsample2d(x0)
                x1 = tf.nn.sigmoid(self.out_conv1(x))
                x1 = nn.upsample2d(x1)
                x2 = tf.nn.sigmoid(self.out_conv2(x))
                x2 = nn.upsample2d(x2)
                x3 = tf.nn.sigmoid(self.out_conv3(x))
                x3 = nn.upsample2d(x3)

                if nn.data_format == "NHWC":
                    tile_cfg = ( 1, resolution // 2, resolution //2, 1)
                else:
                    tile_cfg = ( 1, 1, resolution // 2, resolution //2 )

                z0 =  tf.concat ( ( tf.concat ( (  tf.ones ( (1,1,1,1) ), tf.zeros ( (1,1,1,1) ) ), axis=nn.conv2d_spatial_axes[1] ),
                                    tf.concat ( ( tf.zeros ( (1,1,1,1) ), tf.zeros ( (1,1,1,1) ) ), axis=nn.conv2d_spatial_axes[1] ) ), axis=nn.conv2d_spatial_axes[0] )

                z0 = tf.tile ( z0, tile_cfg )

                z1 =  tf.concat ( ( tf.concat ( ( tf.zeros ( (1,1,1,1) ), tf.ones ( (1,1,1,1) ) ), axis=nn.conv2d_spatial_axes[1] ),
                                    tf.concat ( ( tf.zeros ( (1,1,1,1) ), tf.zeros ( (1,1,1,1) ) ), axis=nn.conv2d_spatial_axes[1] ) ), axis=nn.conv2d_spatial_axes[0] )
                z1 = tf.tile ( z1, tile_cfg )

                z2 =  tf.concat ( ( tf.concat ( (  tf.zeros ( (1,1,1,1) ), tf.zeros ( (1,1,1,1) ) ), axis=nn.conv2d_spatial_axes[1] ),
                                    tf.concat ( (  tf.ones ( (1,1,1,1) ), tf.zeros ( (1,1,1,1) ) ), axis=nn.conv2d_spatial_axes[1] ) ), axis=nn.conv2d_spatial_axes[0] )
                z2 = tf.tile ( z2, tile_cfg )

                z3 =  tf.concat ( ( tf.concat ( (  tf.zeros ( (1,1,1,1) ), tf.zeros ( (1,1,1,1) ) ), axis=nn.conv2d_spatial_axes[1] ),
                                    tf.concat ( (  tf.zeros ( (1,1,1,1) ), tf.ones ( (1,1,1,1) ) ), axis=nn.conv2d_spatial_axes[1] ) ), axis=nn.conv2d_spatial_axes[0] )
                z3 = tf.tile ( z3, tile_cfg )

                x = x0*z0 + x1*z1 + x2*z2 + x3*z3

                return x

        with tf.device ('/CPU:0'):
            #Place holders on CPU
            self.warped_src = tf.placeholder (nn.floatx, bgr_shape)
            self.target_src = tf.placeholder (nn.floatx, bgr_shape)
            self.warped_dst = tf.placeholder (nn.floatx, bgr_shape)
            self.target_dst = tf.placeholder (nn.floatx, bgr_shape)
        
        
        # Initializing model classes
        with tf.device (models_opt_device):
            self.encoder = Encoder(in_ch=input_ch, e_ch=e_dims, name='encoder')
            encoder_out_ch = self.encoder.compute_output_channels ( (nn.floatx, bgr_shape))

            self.bpc = Classifier(in_ch=ae_dims, n_classes=2, name='bpc')

            self.inter = Inter (in_ch=encoder_out_ch, ae_ch=ae_dims, name='inter')

            self.decoder = Decoder(in_ch=ae_dims+2, d_ch=d_dims, name='decoder')
            
            

            self.model_filename_list += [ [self.encoder,     'encoder.npy'    ],
                                          [self.bpc,       'bpc.npy'      ],
                                          [self.inter,       'inter.npy'      ],
                                          [self.decoder, 'decoder.npy']  ]

            if self.is_training:
                self.all_trainable_weights = self.encoder.get_weights() + \
                                             self.bpc.get_weights() +\
                                             self.inter.get_weights() +\
                                             self.decoder.get_weights()

                # Initialize optimizers
                self.src_dst_opt = nn.RMSprop(lr=5e-5, name='src_dst_opt')
                self.src_dst_opt.initialize_variables(self.all_trainable_weights, vars_on_cpu=optimizer_vars_on_cpu )
                self.model_filename_list += [ (self.src_dst_opt, 'src_dst_opt.npy') ]

        if self.is_training:
            # Adjust batch size for multiple GPU
            gpu_count = max(1, len(devices) )
            bs_per_gpu = max(1, 32 // gpu_count)
            self.set_batch_size( gpu_count*bs_per_gpu)

            # Compute losses per GPU
            gpu_pred_src_list = []
            gpu_pred_dst_list = []
            gpu_pred_src_dst_list = []
            
            gpu_G_losses = []
            gpu_C_pos_losses = []
            gpu_C_neg_losses = []
            
            gpu_G_loss_gvs = []
            gpu_C_pos_loss_gvs = []
            gpu_C_neg_loss_gvs = []
            for gpu_id in range(gpu_count):
                with tf.device( f'/DML:{gpu_id}' if len(devices) != 0 else f'/CPU:0' ):
                    batch_slice = slice( gpu_id*bs_per_gpu, (gpu_id+1)*bs_per_gpu )
                    with tf.device(f'/CPU:0'):
                        # slice on CPU, otherwise all batch data will be transfered to GPU first
                        gpu_warped_src   = self.warped_src [batch_slice,:,:,:]
                        gpu_target_src   = self.target_src [batch_slice,:,:,:]
                        gpu_warped_dst   = self.warped_dst [batch_slice,:,:,:]
                        gpu_target_dst   = self.target_dst [batch_slice,:,:,:]
                                                
                    # process model tensors
                    gpu_src_code    = self.inter(self.encoder(gpu_warped_src))
                    gpu_dst_code    = self.inter(self.encoder(gpu_warped_dst))
                    
                    #gpu_src_code_ng = tf.stop_gradient(gpu_src_code)
                    #gpu_dst_code_ng = tf.stop_gradient(gpu_dst_code)
    
                    src_vector = tf.tile(tf.constant( [ [1,0] ], dtype=tf.float32 ), ( tf.shape(gpu_src_code)[0], 1) )
                    dst_vector = tf.tile(tf.constant( [ [0,1] ], dtype=tf.float32 ), ( tf.shape(gpu_dst_code)[0], 1) )

                    gpu_pred_src     = self.decoder ( tf.concat([gpu_src_code, src_vector], axis=-1)  )
                    gpu_pred_dst     = self.decoder ( tf.concat([gpu_dst_code, dst_vector], axis=-1)  )
                    gpu_pred_src_dst = self.decoder ( tf.concat([gpu_dst_code, src_vector], axis=-1)  )
                    
                    gpu_src_c_code     = self.bpc(gpu_pred_src)
                    gpu_dst_c_code     = self.bpc(gpu_pred_dst)
                    #import code
                    #code.interact(local=dict(globals(), **locals()))
  
                    
                    def crossentropy(target, output):
                        output = tf.nn.softmax(output)
                        output = tf.clip_by_value(output, 1e-7, 1 - 1e-7)
                        return tf.reduce_sum(target * -tf.log(output), axis=-1, keepdims=False)

                    def negative_crossentropy(n_classes, output):
                        output = tf.nn.softmax(output)
                        output = tf.clip_by_value(output, 1e-7, 1 - 1e-7)
                        return (1.0/n_classes) * tf.reduce_sum(tf.log(output), axis=-1, keepdims=False)
    
                    gpu_G_loss = tf.reduce_mean(tf.square(gpu_target_src-gpu_pred_src), axis=[1,2,3])
                    gpu_G_loss += tf.reduce_mean(tf.square(gpu_target_dst-gpu_pred_dst), axis=[1,2,3])
                    
                    gpu_c_pos_loss = 0.01*(crossentropy(src_vector, gpu_src_c_code ) + crossentropy(dst_vector, gpu_dst_c_code ))
                    
                    gpu_c_neg_loss = 0.01*(negative_crossentropy( 2, gpu_src_c_code ) + negative_crossentropy( 2, gpu_dst_c_code ))

                    gpu_pred_src_list.append(gpu_pred_src)
                    gpu_pred_dst_list.append(gpu_pred_dst)
                    gpu_pred_src_dst_list.append(gpu_pred_src_dst)
            
                    gpu_G_losses += [gpu_G_loss]
                    gpu_C_pos_losses += [gpu_c_pos_loss]
                    gpu_C_neg_losses += [gpu_c_neg_loss] 
                    
                    G_weights = self.encoder.get_weights() + self.inter.get_weights() + self.decoder.get_weights()
                    C_pos_weights = self.bpc.get_weights()
                    C_neg_weights = self.encoder.get_weights() + self.inter.get_weights() 
  
                    gpu_G_loss_gvs += [ nn.gradients ( gpu_G_loss, G_weights ) ]
                    gpu_C_pos_loss_gvs += [ nn.gradients ( gpu_c_pos_loss, C_pos_weights ) ]
                    gpu_C_neg_loss_gvs += [ nn.gradients ( gpu_c_neg_loss, C_neg_weights ) ]
                    
                    

            # Average losses and gradients, and create optimizer update ops
            with tf.device (models_opt_device):
                pred_src     = nn.concat(gpu_pred_src_list, 0)
                pred_dst     = nn.concat(gpu_pred_dst_list, 0)
                pred_src_dst = nn.concat(gpu_pred_src_dst_list, 0)
                G_loss = nn.average_tensor_list(gpu_G_losses)
                C_pos_loss = nn.average_tensor_list(gpu_C_pos_losses)
                C_neg_loss = nn.average_tensor_list(gpu_C_neg_losses)

                G_loss_gv = nn.average_gv_list (gpu_G_loss_gvs)
                C_pos_loss_gv = nn.average_gv_list (gpu_C_pos_loss_gvs)
                C_neg_loss_gv = nn.average_gv_list (gpu_C_neg_loss_gvs)
                
                G_loss_gv_op = self.src_dst_opt.get_update_op (G_loss_gv)
                C_pos_loss_gv_op = self.src_dst_opt.get_update_op (C_pos_loss_gv)
                C_neg_loss_gv_op = self.src_dst_opt.get_update_op (C_neg_loss_gv)

            # Initializing training and view functions
            def G_train(warped_src, target_src, warped_dst, target_dst, ):
                l, _ = nn.tf_sess.run ( [ G_loss, G_loss_gv_op], feed_dict={self.warped_src :warped_src, self.target_src :target_src, 
                                                                            self.warped_dst :warped_dst, self.target_dst :target_dst })
                return np.mean(l)
            self.G_train = G_train
            
            def C_pos_train(warped_src, warped_dst):
                l, _ = nn.tf_sess.run ( [ C_pos_loss, C_pos_loss_gv_op], feed_dict={self.warped_src :warped_src, self.warped_dst :warped_dst})
                return np.mean(l)
            self.C_pos_train = C_pos_train
            
            def C_neg_train(warped_src, warped_dst):
                l, _ = nn.tf_sess.run ( [ C_neg_loss, C_neg_loss_gv_op], feed_dict={self.warped_src :warped_src, self.warped_dst :warped_dst})
                return np.mean(l)
            self.C_neg_train = C_neg_train

            def AE_view(warped_src, warped_dst):
                return nn.tf_sess.run ([pred_src, pred_dst, pred_src_dst],
                                            feed_dict={self.warped_src:warped_src, self.warped_dst:warped_dst})
            self.AE_view = AE_view
            
        else:
            # Initializing merge function
            with tf.device( f'/DML:0' if len(devices) != 0 else f'/CPU:0'):
                gpu_dst_code     = self.inter(self.encoder(self.warped_dst))
                gpu_pred_src_dst, gpu_pred_src_dstm = self.decoder_src(gpu_dst_code)
                _, gpu_pred_dst_dstm = self.decoder_dst(gpu_dst_code)

            def AE_merge( warped_dst):

                return nn.tf_sess.run ( [gpu_pred_src_dst, gpu_pred_dst_dstm, gpu_pred_src_dstm], feed_dict={self.warped_dst:warped_dst})

            self.AE_merge = AE_merge

        # Loading/initializing all models/optimizers weights
        for model, filename in io.progress_bar_generator(self.model_filename_list, "Initializing models"):
            if self.pretrain_just_disabled:
                do_init = False
                if model == self.inter:
                    do_init = True
            else:
                do_init = self.is_first_run()

            if not do_init:
                do_init = not model.load_weights( self.get_strpath_storage_for_file(filename) )

            if do_init and self.pretrained_model_path is not None:
                pretrained_filepath = self.pretrained_model_path / filename
                if pretrained_filepath.exists():
                    do_init = not model.load_weights(pretrained_filepath)

            if do_init:
                model.init_weights()

        # initializing sample generators
        if self.is_training:
            training_data_src_path = self.training_data_src_path if not self.pretrain else self.get_pretraining_data_path()
            training_data_dst_path = self.training_data_dst_path if not self.pretrain else self.get_pretraining_data_path()

            cpu_count = min(multiprocessing.cpu_count(), 8)
            src_generators_count = cpu_count // 2
            dst_generators_count = cpu_count // 2

            self.set_training_data_generators ([
                    SampleGeneratorFace(training_data_src_path, debug=self.is_debug(), batch_size=self.get_batch_size(),
                        sample_process_options=SampleProcessor.Options(random_flip=True if self.pretrain else False),
                        output_sample_types = [ {'sample_type': SampleProcessor.SampleType.FACE_IMAGE,'warp':True,  'transform':True, 'channel_type' : SampleProcessor.ChannelType.BGR,                                                           'face_type':self.face_type, 'data_format':nn.data_format, 'resolution': resolution},
                                                {'sample_type': SampleProcessor.SampleType.FACE_IMAGE,'warp':False, 'transform':True, 'channel_type' : SampleProcessor.ChannelType.BGR,                                                           'face_type':self.face_type, 'data_format':nn.data_format, 'resolution': resolution},
                                                ],
                        generators_count=src_generators_count ),

                    SampleGeneratorFace(training_data_dst_path, debug=self.is_debug(), batch_size=self.get_batch_size(),
                        sample_process_options=SampleProcessor.Options(random_flip=True if self.pretrain else False),
                        output_sample_types = [ {'sample_type': SampleProcessor.SampleType.FACE_IMAGE,'warp':True,  'transform':True, 'channel_type' : SampleProcessor.ChannelType.BGR,                                                           'face_type':self.face_type, 'data_format':nn.data_format, 'resolution': resolution},
                                                {'sample_type': SampleProcessor.SampleType.FACE_IMAGE,'warp':False, 'transform':True, 'channel_type' : SampleProcessor.ChannelType.BGR,                                                           'face_type':self.face_type, 'data_format':nn.data_format, 'resolution': resolution},
                                                ],
                        generators_count=dst_generators_count )
                             ])

            self.last_samples = None

    #override
    def get_model_filename_list(self):
        return self.model_filename_list

    #override
    def onSave(self):
        for model, filename in io.progress_bar_generator(self.get_model_filename_list(), "Saving", leave=False):
            model.save_weights ( self.get_strpath_storage_for_file(filename) )

    #override
    def onTrainOneIter(self):
        bs = self.get_batch_size()
        
        samples = self.last_samples = self.generate_next_samples()
        ( (warped_src, target_src,), \
          (warped_dst, target_dst,) ) = samples
        
        G_loss = self.G_train (warped_src, target_src, warped_dst, target_dst)
        
        C_pos_loss = self.C_pos_train (warped_src, warped_dst)
        C_neg_loss = self.C_neg_train (warped_src, warped_dst)

        return ( ('G_loss', G_loss), ('C_pos_loss', C_pos_loss), ('C_neg_loss', C_neg_loss), )

    #override
    def onGetPreview(self, samples):
        ( (warped_src, target_src,),
          (warped_dst, target_dst,) ) = samples
          
        S, D, SS, DD, DS = [ np.clip( nn.to_data_format(x,"NHWC", self.model_data_format), 0.0, 1.0) for x in ([target_src,target_dst] + \
                                                  self.AE_view (target_src, target_dst) 
                                                  ) ]
                                                  
        #import code
        #code.interact(local=dict(globals(), **locals()))

        

        n_samples = min(4, self.get_batch_size() )
        result = []
        st = []
        for i in range(n_samples):
            ar = S[i], SS[i], D[i], DD[i], DS[i]
            st.append ( np.concatenate ( ar, axis=1) )

        result += [ ('TEST', np.concatenate (st, axis=0 )), ]

        return result

    def predictor_func (self, face=None):
        face = nn.to_data_format(face[None,...], self.model_data_format, "NHWC")

        bgr, mask_dst_dstm, mask_src_dstm = [ nn.to_data_format(x, "NHWC", self.model_data_format).astype(np.float32) for x in self.AE_merge (face) ]
        mask = mask_dst_dstm[0] * mask_src_dstm[0]
        return bgr[0], mask[...,0]

    #override
    def get_MergerConfig(self):
        import merger
        return self.predictor_func, (self.resolution, self.resolution, 3), merger.MergerConfigMasked(face_type=self.face_type,
                                     default_mode = 'overlay',
                                    )

Model = QModel
